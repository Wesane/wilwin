
if q1 = 